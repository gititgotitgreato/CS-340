# Python Code to Insert, Read, Update and Delete Documents

from pymongo import MongoClient, errors

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'SNHU1234' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
    def findRec(self):
        record = self.collection.find_one(
            {"rec_num": {"$exists": True}},
            projection = {"rec_num": 1},
            sort = [("rec_num", -1)],
        )
        return record.get("rec_num", 0) + 1 if record else 1
        
    # Create method to implement the C in CRUD. 
     def create(self, data):
        """Insert a document and assign its record number."""
        if not isinstance(data, dict) or not data:
            raise ValueError("data must be a non-empty dict.")

        try:
            document = data.copy()
            document["rec_num"] = self.findRec()
            self.collection.insert_one(document)
            return True
        except errors.PyMongoError:
            logger.exception("Unable to create animal record.")
            return False 

    # Read method to implement the R in CRUD.
    def read(self, query):
        if not isinstance(query, dict):
            try:
                # Find documents matching query
                docs = list(self.collection.find(query)) 
                return docs
            
            except errors.PyMongoError as e:
                print("A read error has occurred.")
                return [] # If error occurs, return empty list
        else:
            raise ValueError("Nothing to read, because query parameter is empty.") 
    
    # Update method to implement the U in CRUD.
    def update(self, query, update_values):
        if not isinstance(query, dict) or not isinstance(update_values, dict):
            raise ValueError("query and update_values must be dictionaries.")
        if not update_values:
            raise ValueError("update_values must not be empty.")
        try:
            result = self.collection.update_many(query, {'$set': update_values})
            return result.modified_count # number of updated documents
            
        except errors.PyMongoError as e:
                print("An update error has occurred.")
        else:
            raise ValueError("Cannot update because query or update_values parameter is empty.") 
                
    # Delete method to implement the D in CRUD.    
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query) 
                return result.deleted_count # number of deleted documents
            
            except errors.PyMongoError as e:
                print("A deletion error has occurred.")
        
        else:
            raise ValueError("Nothing to delete, because query parameter is empty.") 